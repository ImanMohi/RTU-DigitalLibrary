class Question {
  constructor(text, buttons, answer) {
    this.text = text;
    this.buttons = buttons;
    this.answer = answer;
  }
  isCorrectAnswer(choice) {
    return this.answer === choice;
  }
}

let questions = [
  new Question(
    "Which of the following languages is more suited to a structured program?", [
      "PL/1",
      "FORTRAN",
      "PASCAL",
      "Node of the above"
    ],

    "Node of the above"
  ),

  new Question(
    "A computer assisted method for the recording and analyzing of existing or hypothetical systems is", [
      "Data transmission",
      "Data flow",
      "Data capture",
      "Data processing"
    ],

    "Data flow"
  ),

  new Question(
    "The brain of any computer system is", [
      "ALU",
      "Memory",
      "CPU",
      "Control Unit"
    ],

    "CPU"
  ),
  new Question(
    "What difference does the 5th generation computer have from other generation computers?", [
      "Technological advancement",
      "Scientific code",
      "Object Oriented Programming",
      "All of the above"
    ],

    "Technological advancement"
  ),
  new Question(
    "A section of code to which control is transferred when a processor is interrupted is known as", [
      "M",
      "SVC",
      "IP",
      "MDR"
    ],

    "M"
  ),
  new Question(
    "The binary system uses powers of", [
      "2",
      "10",
      "8",
      "16"
    ],

    "2"
  ),
  new Question(
    "A computer program that converts assembly language to machine language is", [
      "Compiler",
      "Interpreter",
      "Assembler",
      "Comparator"
    ],

    "Assembler"
  ),
  new Question(
    "The time required for the fetching and execution of one simple machine instruction is", [
      "Delay time",
      "CPU cycle",
      "Real time",
      "Seek time"
    ],

    "CPU cycle",
  ),
  new Question(
    "Which access method is used for obtaining a record from a cassette tape?", [
      "Direct",
      "Sequential",
      "Random",
      "All of the above"
    ],

    "Sequential",
  ),

  new Question(
    "Which part interprets program instructions and initiate control operations.", [
      "Input",
      "Control unit",
      "Logic unit",
      "None of the above"
    ],

    "None of the above"
  )
];


class Quiz {
  constructor(questions) {
    this.score = 0;
    this.questions = questions;
    this.currentQuestionIndex = 0;
  }
  getCurrentQuestion() {
    return this.questions[this.currentQuestionIndex];
  }
  click(answer) {
    if (this.getCurrentQuestion().isCorrectAnswer(answer)) {
      this.score++;
    }
    this.currentQuestionIndex++;
  }
  hasEnded() {
    return this.currentQuestionIndex >= this.questions.length;
  }
}

const display = {
  elementShown: function (id, text) {
    let element = document.getElementById(id);
    element.innerHTML = text;
  },
  endQuiz: function () {
    endQuizHTML = `
      <h1>Yaa, Quiz Comlpeted !</h1>
     <h2>Thanks for Participating : )  </h2>
     <br>
          <h2>Hope you like it!</h2>

     <br>
      <h3> Your score is : ${quiz.score} / ${quiz.questions.length}</h3>`;
    this.elementShown("quiz", endQuizHTML);
  },
  question: function () {
    this.elementShown("question", quiz.getCurrentQuestion().text);
  },
  buttons: function () {
    let buttons = quiz.getCurrentQuestion().buttons;

    clickHandler = (id, click) => {
      document.getElementById(id).onclick = function () {
        quiz.click(click);
        quizApp();
      }
    }
    for (let i = 0; i < buttons.length; i++) {
      this.elementShown("choice" + i, buttons[i]);
      clickHandler("click" + i, buttons[i]);
    }
  },
  progress: function () {
    let currentQuestionNumber = quiz.currentQuestionIndex + 1;
    this.elementShown("progress", "Question " + currentQuestionNumber + " out of " + quiz.questions.length);
  },
};

quizApp = () => {
  if (quiz.hasEnded()) {
    display.endQuiz();
  } else {
    display.question();
    display.buttons();
    display.progress();
  }
}
let quiz = new Quiz(questions);
quizApp();